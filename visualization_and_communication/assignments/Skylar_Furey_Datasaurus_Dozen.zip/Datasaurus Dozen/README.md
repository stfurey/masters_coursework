D3 Workshop: The Datasaurus Dozen
Skylar Furey

Project Load Instructions:
1. Unzip files to desired directory
2. Open Terminal/Command Prompt
3. Change directory to directory with unzipped files
4. Run command python -m http.server
5. Open a Web Browser and go to: http://localhost:8000/Dinosaurus_Dozen.html


Visualization Descriptions
1. Bar plots are Juxtaposed
	Bar plot 1 (Green): Represents the Star dataset
	Bar plot 2 (Purple): Represents the Bullseye dataset

2. Scatter plots are Super positioned
	Scatter plot 1 (Blue): Represents the Dino dataset
	Scatter plot 2 (Orange): Represents the Circle dataset

2. Line graphs are Super positioned
	Line graph 1 (Red): Represents the h_lines dataset
	Line graph 2 (Dark Blue): Represents the v_lines dataset